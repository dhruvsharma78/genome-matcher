#include "Trie.h"
#include "provided.h"
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void printVector(vector<int> ans);

int main(){
    cerr<<endl;
    
    // Trie<int> x;
    // x.insert("hi",9);
    // x.insert("hi",17);
    // x.insert("hat",7);
    // x.insert("hat",8);
    // x.insert("hat",9);
    // x.insert("hit",1);
    // x.insert("hit",2);
    // x.insert("hip",10);
    // x.insert("hip",20);
    // x.insert("a", 14);
    // x.insert("to",22);
    // x.insert("to",23);
    // x.insert("tap",19632);
    // x.insert("hipe",23);
    // x.insert("hite",11);
    
    // printVector(x.find("hit",false));
    
    // string filename = "/Users/dhruvsharma/Desktop/School/Winter_19/CS32/Projects/Project_4/Gee-nomics/data/Halobacterium_jilantaiense.txt";
    // ifstream strm(filename);
    // if(!strm){
    //     cout << "Cannot open " << filename << endl;
    //     return 3;
    // }
    
    // vector<Genome> vg;
    // bool success = Genome::load(strm, vg);
    // cout<<vg.size()<<endl;
    // cout<<vg[1].name()<<endl;
    // cout<<vg[1].length()<<endl;
    // cout<<"\n\n\n";
    
    // GenomeMatcher gm(3);
    // vector<Genome> v;
    // Genome a("1", "ACTG");
    // Genome b("2","TCGACT");
    // Genome c("3", "TCTCG");
    // gm.addGenome(a);
    // gm.addGenome(b);
    // gm.addGenome(c);
    
    Genome x("Genome 1", "CGGTGTACNACGACTGGGGATAGAATATCTTGACGTCGTACCGGTTGTAGTCGTTCGACCGAAGGGTTCCGCGCCAGTAC");
    Genome y("Genome 2", "TAACAGAGCGGTNATATTGTTACGAATCACGTGCGAGACTTAGAGCCAGAATATGAAGTAGTGATTCAGCAACCAAGCGG");
    Genome z("Genome 3", "TTTTGAGCCAGCGACGCGGCTTGCTTAACGAAGCGGAAGAGTAGGTTGGACACATTNGGCGGCACAGCGCTTTTGAGCCA");
    
    GenomeMatcher gm(4);
    gm.addGenome(x);
    gm.addGenome(y);
    gm.addGenome(z);
    std::vector<DNAMatch> matches;
    std::vector<GenomeMatch> matches2;
    bool result;
    result = gm.findGenomesWithThisDNA("ACGTGCGAGACTTAGAGCC", 12, true, matches);
    // cout<<boolalpha<<result<<endl;
    // for(int i=0; i<matches.size(); i++){
    //     cout<<matches[i].genomeName<<" of length "<<matches[i].length<<" at position "<<matches[i].position<<endl;
    // }
    gm.findRelatedGenomes(x,12,true,44,matches2);
}

void printVector(vector<int> ans){
    cout<<"Results: ";
    for(int i=0; i<ans.size(); i++){
        std::cout<<" "<<ans[i]<<" ";
    }
    cout<<endl;
}
